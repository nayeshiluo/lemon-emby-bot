# Audit result — 2026-10-08

PASS: 36 candidate files match Git blob SHA; original Git worktree remains clean.
PASS: runtime DB, post-test backup and restore copy all integrity_check=ok; users=0, codes=2, logs=3.
PASS: 12 real Emby/DB checks have complete results; business test accounts were removed.
PASS: configuration and secrets 0600, acceptance root 0700.
FIXED: Emby runs as UID2; root supervisors remain as provided by the official image.
FIXED: removed unused declared port mapping; Docker internal network, no ports, no restart, 512MiB/0.5CPU preserved.
PASS: hardened service returned public HTTP200 with version4.10.1.0, then was stopped.
LIMIT: no real Telegram delivery, no natural scheduler slot, no full shared main.py process; release remains BLOCKED.
BACKUP LIMIT: uploaded package is sanitized reconstruction backup, not full authentication disaster recovery. Source code is restored from its already-backed-up GitHub commit.
