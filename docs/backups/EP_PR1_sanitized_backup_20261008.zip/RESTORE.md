# EP PR1 audited, sanitized reconstruction backup

Candidate: 918bf495f62d162b5610c3e7bc3b18d6e9c4a4d9
Real isolated Emby: 4.10.1.0
Release gate: BLOCKED. Real Telegram delivery, natural scheduling, and shared main process are NOT RUN.

Included: source reference and all 36 Git blob hashes; isolated test DB with consumed test card values replaced; sanitized config template; acceptance scripts; real Emby and audit evidence; hardened Docker service specification; SHA256SUMS.json.

Excluded: Emby administrator password, Emby API Key, Web admin secret, Telegram Token, raw server authentication DB/config, full Docker image, full Git repository. The full private Emby configuration backup stays on LA at /opt/ep-acceptance-20261008/emby-private-full-after-audit.tar.gz. Private AWS config and secrets remain in the protected acceptance directory.

This upload supports reconstruction with newly generated credentials; it does NOT preserve the original server authentication identities. No production users exist in this DB. Consumed fixture card values are redacted and cannot be used as real redemption secrets.

Restore:
1. Extract into a NEW private directory. Verify every SHA256 in SHA256SUMS.json before copying anything.
2. Restore the source from the existing GitHub repository at the exact candidate SHA above; validate each file with acceptance/source-manifest.json. Do not overwrite an unrelated checkout.
3. On an isolated LA directory, pull the image_digest in service/service-manifest.json. Create a dedicated Docker internal network and container with UID=2, GID=2, 512MiB memory and memory+swap limit, 0.5 CPU, no restart, no published ports. Bind only the new config and empty test-media directories. Grant UID2 access to the config mount.
4. Initialize a NEW administrator and dedicated API Key; create a safe non-admin template. Do not restore authentication from this sanitized archive. For exact original authentication recovery, use the protected full local server backup separately.
5. Restore acceptance/data/acceptance.sqlite3 with SQLite backup API to the dedicated path; PRAGMA integrity_check must be ok. Expected counts: users=0, codes=2, logs=3. Start from acceptance/source/config.template.yaml, generate a new server.secret_key, and fill only dedicated Emby and test Bot fields. Scripts currently refer to /home/ubuntu/hermes-jobs/releases/ep-acceptance-20261008; restore there or adapt those paths explicitly.
6. Use an SSH tunnel bound to 127.0.0.1 and the container's CURRENT internal address. Run preflight before main.py. Keep Bot/scheduler/Web in one process and one Database instance. Obtain actual Telegram evidence before declaring any release gate passed.
7. On completion, clean only accounts recorded in account-whitelist.json, stop the acceptance container and SSH tunnel, and keep the baseline backups.

Do not publish this archive to GitHub automatically. Evidence IDs refer to isolated test fixtures; Telegram replies were locally captured, not sent.
