import pathlib,json,urllib.request,urllib.error,secrets,os,yaml
os.umask(0o077)
root=pathlib.Path("/home/ubuntu/hermes-jobs/releases/ep-acceptance-20261008")
base="http://127.0.0.1:18096/emby"
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs): return None
opener=urllib.request.build_opener(NoRedirect())
headers={"Content-Type":"application/json","X-Emby-Authorization":'MediaBrowser Client="EP-Acceptance", Device="IsolatedTest", DeviceId="epacc-20261008", Version="1"'}
def request(method,path,data=None,token=None):
 h=dict(headers)
 if token:h["X-Emby-Token"]=token
 body=json.dumps(data).encode() if data is not None else None
 req=urllib.request.Request(base+path,data=body,method=method,headers=h)
 try:
  with opener.open(req,timeout=12) as r:
   raw=r.read()
   print("api_status",method,path.split("?")[0],r.status,flush=True)
   return json.loads(raw) if raw and "json" in r.headers.get("Content-Type","") else raw.decode()
 except urllib.error.HTTPError as e:
  print("api_failure",method,path.split("?")[0],e.code,flush=True)
  raise RuntimeError("Setup HTTP failure") from None
private=root/"emby-test-secrets.json"
if private.exists():raise SystemExit("Existing setup secrets; inspect before reuse")
username="epacc_admin_20261008"
password=secrets.token_urlsafe(28)
private.write_text(json.dumps({"admin_username":username,"admin_password":password},indent=2))
private.chmod(0o600)
request("GET","/Startup/User")
config=request("GET","/Startup/Configuration")
config.update({"UICulture":"en-US","MetadataCountryCode":"US","PreferredMetadataLanguage":"en"})
request("POST","/Startup/Configuration",config)
request("POST","/Startup/User",{"Name":username,"Password":password,"ConnectUserName":""})
request("POST","/Startup/RemoteAccess",{"EnableRemoteAccess":False,"EnableAutomaticPortMapping":False})
request("POST","/Startup/Complete")
auth=request("POST","/Users/AuthenticateByName",{"Username":username,"Pw":password})
token=auth.get("AccessToken")
assert token and auth["User"]["Policy"]["IsAdministrator"] is True
app="EP-Acceptance-20261008"
request("POST","/Auth/Keys?App="+app,token=token)
keys=request("GET","/Auth/Keys",token=token)
items=keys.get("Items",[]) if isinstance(keys,dict) else keys
keyrow=next((k for k in items if k.get("AppName",k.get("App"))==app),None)
if not keyrow:
 print("key_response_field_names",[list(k.keys()) for k in items],flush=True)
 raise SystemExit("Could not locate dedicated API Key")
key=keyrow.get("AccessToken") or keyrow.get("Key")
assert key
info=request("GET","/System/Info",token=key)
template=request("POST","/Users/New",{"Name":"epacc_template_20261008"},token=key)
uid=template["Id"]
template_user=request("GET","/Users/"+uid,token=key)
policy=template_user["Policy"]
policy.update({"IsAdministrator":False,"IsDisabled":True,"EnableRemoteAccess":False,"EnableAllFolders":False,"EnabledFolders":[],"EnableMediaPlayback":False,"EnableContentDeletion":False})
request("POST","/Users/"+uid+"/Policy",policy,token=key)
template_user=request("GET","/Users/"+uid,token=key)
assert template_user["Policy"]["IsAdministrator"] is False
# Keep template itself disabled; creating accounts copies a safe, enabled policy after below change.
policy["IsDisabled"]=False
request("POST","/Users/"+uid+"/Policy",policy,token=key)
data=json.loads(private.read_text());data.update({"api_key":key,"template_user_id":uid,"server_url":base,"version":info.get("Version")})
private.write_text(json.dumps(data,indent=2));private.chmod(0o600)
cfgpath=root/"source/config.yaml"
cfg=yaml.safe_load(cfgpath.read_text());cfg["emby"].update({"server_url":base,"public_url":base,"api_key":key,"template_user_id":uid})
cfgpath.write_text(yaml.safe_dump(cfg,allow_unicode=True,sort_keys=False));cfgpath.chmod(0o600)
result={"status":"EMBY_READY_TELEGRAM_BLOCKED","version":info.get("Version"),"admin_account_created":True,"dedicated_api_key_created":True,"template_non_admin":True,"template_no_media_permissions":True,"credentials_file_mode":"0600","server_url":base,"telegram_configured":False,"admin_user_id":auth["User"]["Id"],"template_user_id":uid}
(root/"evidence/emby-setup-results.json").write_text(json.dumps(result,indent=2))
print(json.dumps(result),flush=True)
