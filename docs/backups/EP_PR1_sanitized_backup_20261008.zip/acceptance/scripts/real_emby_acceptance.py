import asyncio,pathlib,json,datetime,secrets,sqlite3,shutil,sys,logging,types,os
import aiohttp,yaml
os.umask(0o077)
root=pathlib.Path("/home/ubuntu/hermes-jobs/releases/ep-acceptance-20261008")
sys.path.insert(0,str(root/"source"))
from core.database import Database
from core.emby import EmbyClient
from core.scheduler import BackgroundScheduler
from bot.telegram_bot import LemonEmbyBot
private=json.loads((root/"emby-test-secrets.json").read_text())
config=yaml.safe_load((root/"source/config.yaml").read_text())
dbpath=root/"data/acceptance.sqlite3"
with sqlite3.connect(dbpath) as src:
 assert src.execute("SELECT COUNT(*) FROM users").fetchone()[0]==0
 with sqlite3.connect(root/"backups/acceptance-configured-before.sqlite3") as dst:src.backup(dst)
shutil.copy2(root/"source/config.yaml",root/"backups/config-configured-before.yaml")
db=Database(str(dbpath))
client=EmbyClient(private["server_url"],private["api_key"],private["template_user_id"])
# No Telegram client or real Telegram identity is used in this harness.
bot=LemonEmbyBot.__new__(LemonEmbyBot)
bot.db=db;bot.emby=client;bot.config=config;bot.admin_ids=[900000009]
scheduler=BackgroundScheduler(db,client,config,notify_func=None)
tid=900000001
steps=[];created=[];fail=None
authheader={'X-Emby-Authorization':'MediaBrowser Client="EP-LifeTest", Device="IsolatedTest", DeviceId="epacc-life-20261008", Version="1"'}
class LocalReplyCapture:
 reply_to_message=None
 def __init__(self): self.replies=[]
 async def reply_text(self,text,**kwargs): self.replies.append(text)
def update(who=tid):
 return types.SimpleNamespace(effective_user=types.SimpleNamespace(id=who),effective_chat=types.SimpleNamespace(type="private"),message=LocalReplyCapture())
async def authenticate(username,password):
 async with aiohttp.ClientSession() as session:
  async with session.post(private["server_url"]+"/Users/AuthenticateByName",json={"Username":username,"Pw":password},headers=authheader,allow_redirects=False,timeout=10) as response:
   status=response.status
   result=await response.json() if status==200 else None
   return status,result
def mark(name,**details):
 entry={"test":name,"status":"PASS",**details};steps.append(entry)
 print(json.dumps(entry),flush=True)
def whitelist():
 (root/"account-whitelist.json").write_text(json.dumps({"run":"ep-acceptance-20261008","created_accounts":created,"scope":"Only created accounts in this harness; admin and template excluded"},indent=2))
def expire():
 with sqlite3.connect(dbpath) as con:
  con.execute("UPDATE users SET expiry_date=? WHERE tg_id=?",((datetime.datetime.now(datetime.timezone.utc)-datetime.timedelta(minutes=1)).isoformat(),tid))
  con.commit()
async def main():
 global fail
 username="epacc_20261008_"+secrets.token_hex(4)
 pw=secrets.token_urlsafe(22)
 pw2=secrets.token_urlsafe(22)
 try:
  info=await client.get_system_info()
  assert info and info["Version"]=="4.10.1.0"
  template=await client.get_user(private["template_user_id"])
  assert template["Policy"]["IsAdministrator"] is False
  mark("real_server_and_safe_template",version=info["Version"])
  user=await client.create_user(username,pw)
  assert user and user["Id"]
  uid=user["Id"];created.append({"emby_user_id":uid,"username":username,"tg_id_fixture_only":tid,"deleted":False});whitelist()
  user=await client.get_user(uid)
  assert user["Policy"]["IsAdministrator"] is False and user["Policy"]["EnableAllFolders"] is False
  status,auth=await authenticate(username,pw)
  assert status==200 and auth["User"]["Id"]==uid
  assert await db.create_user_record(tid,uid,username,days=1)
  await db.add_user_points(tid,13)
  assert not await db.create_user_record(tid,"fixture-conflicting-id","fixture-conflicting-name")
  current=await db.get_user_by_tg(tid)
  assert current["emby_user_id"]==uid and current["points"]==13
  mark("real_create_password_policy_login_and_binding",is_admin=False,duplicate_binding_rejected=True)
  u=update()
  await bot.cmd_resetpw(u,types.SimpleNamespace(args=[pw2]))
  status,_=await authenticate(username,pw2);assert status==200
  old_status,_=await authenticate(username,pw);assert old_status in (401,403)
  mark("real_password_reset_new_login_old_password_rejected",new_login_status=status,old_login_status=old_status,telegram_reply_captured_locally=True)
  expire()
  invalid=EmbyClient(private["server_url"],"INVALID-TEST-FIXTURE-NOT-A-REAL-KEY",private["template_user_id"])
  badscheduler=BackgroundScheduler(db,invalid,config,notify_func=None)
  await badscheduler.check_expirations()
  current=await db.get_user_by_tg(tid)
  assert current["is_disabled"]==0
  assert (await client.get_user(uid))["Policy"]["IsDisabled"] is False
  mark("real_http_401_expiry_failure_preserves_local_and_emby_state")
  await scheduler.check_expirations()
  current=await db.get_user_by_tg(tid)
  assert current["is_disabled"]==1 and current["disabled_reason"]=="expired"
  assert (await client.get_user(uid))["Policy"]["IsDisabled"] is True
  status,_=await authenticate(username,pw2);assert status in (401,403)
  mark("real_expiry_disable_and_login_denial",disabled_reason=current["disabled_reason"],login_status=status,manual_scheduler_invocation=True)
  code=await db.generate_code("days",1,900000009)
  u=update();await bot.cmd_redeem(u,types.SimpleNamespace(args=[code]))
  current=await db.get_user_by_tg(tid)
  assert current["is_disabled"]==0 and current["disabled_reason"] is None
  assert (await client.get_user(uid))["Policy"]["IsDisabled"] is False
  status,_=await authenticate(username,pw2);assert status==200
  expiry=current["expiry_date"]
  u=update();await bot.cmd_redeem(u,types.SimpleNamespace(args=[code]))
  assert (await db.get_user_by_tg(tid))["expiry_date"]==expiry
  with sqlite3.connect(dbpath) as con:card=con.execute("SELECT used_by,used_at FROM codes WHERE code=?",(code,)).fetchone()
  assert card[0]==tid and card[1]
  mark("real_renewal_reenable_and_duplicate_redemption_rejection",login_status=status,expiry_unchanged_on_repeat=True,telegram_input_simulated=True)
  u=update(900000009);await bot.cmd_ban(u,types.SimpleNamespace(args=[username]))
  assert (await db.get_user_by_tg(tid))["disabled_reason"]=="admin"
  assert (await client.get_user(uid))["Policy"]["IsDisabled"] is True
  code2=await db.generate_code("days",1,900000009)
  u=update();await bot.cmd_redeem(u,types.SimpleNamespace(args=[code2]))
  await scheduler.check_expirations()
  current=await db.get_user_by_tg(tid)
  assert current["is_disabled"]==1 and current["disabled_reason"]=="admin"
  assert (await client.get_user(uid))["Policy"]["IsDisabled"] is True
  mark("real_admin_ban_preserved_after_renewal_and_inspection",telegram_command_input_simulated=True)
  u=update(900000009);await bot.cmd_unban(u,types.SimpleNamespace(args=[username]))
  assert (await db.get_user_by_tg(tid))["is_disabled"]==0
  assert (await client.get_user(uid))["Policy"]["IsDisabled"] is False
  mark("real_explicit_admin_unban")
  assert await client.set_user_disabled(uid,True)
  with sqlite3.connect(dbpath) as con:
   con.execute("UPDATE users SET is_disabled=1,disabled_reason=NULL WHERE tg_id=?",(tid,));con.commit()
  assert await db.extend_user_expiry(tid,1)
  assert await bot._reactivate_if_disabled(tid) is False
  await scheduler.check_expirations()
  assert (await db.get_user_by_tg(tid))["is_disabled"]==1
  assert (await client.get_user(uid))["Policy"]["IsDisabled"] is True
  mark("real_unknown_reason_disable_preserved",legacy_reason_fixture_only=True)
  u=update(900000009);await bot.cmd_unban(u,types.SimpleNamespace(args=[username]))
  invalid_template_client=EmbyClient(private["server_url"],private["api_key"],"00000000000000000000000000000000")
  cleanupname="epacc_abort_"+secrets.token_hex(4)
  assert await invalid_template_client.create_user(cleanupname,secrets.token_urlsafe(20)) is None
  assert await client.get_user_by_name(cleanupname) is None
  mark("real_incomplete_user_cleanup_after_template_lookup_failure")
  bot.emby=invalid
  u=update(900000009);await bot.cmd_deluser(u,types.SimpleNamespace(args=[username]))
  assert await db.get_user_by_tg(tid)
  assert await client.get_user(uid)
  assert any("删除失败" in text for text in u.message.replies)
  mark("real_http_401_delete_failure_preserves_binding_and_reports_failure",telegram_reply_captured_locally=True)
  bot.emby=client
  u=update(900000009);await bot.cmd_deluser(u,types.SimpleNamespace(args=[username]))
  assert await db.get_user_by_tg(tid) is None
  assert await client.get_user_by_name(username) is None
  created[0]["deleted"]=True;whitelist()
  mark("real_test_account_deletion_and_local_cleanup")
 except Exception as e:
  fail={"exception_class":type(e).__name__,"completed_tests":len(steps)}
  print("lifecycle_failure",json.dumps(fail),flush=True)
 finally:
  bot.emby=client
  for entry in created:
   if not entry["deleted"]:
    existing=await client.get_user(entry["emby_user_id"])
    if existing and existing.get("Name")==entry["username"]:
     if await client.delete_user(entry["emby_user_id"]):
      await db.delete_user_record(entry["tg_id_fixture_only"]);entry["deleted"]=True
  whitelist()
  with sqlite3.connect(dbpath) as con:
   integrity=con.execute("PRAGMA integrity_check").fetchone()[0]
   counts={t:con.execute("SELECT COUNT(*) FROM "+t).fetchone()[0] for t in ["users","codes","logs"]}
   with sqlite3.connect(root/"backups/acceptance-after-emby-lifecycle.sqlite3") as dest:con.backup(dest)
  users=await client.get_users()
  remaining=[u["Name"] for u in users if u.get("Name","").startswith(("epacc_20261008_","epacc_abort_"))]
  result={"candidate_sha":"918bf495f62d162b5610c3e7bc3b18d6e9c4a4d9","real_server":"Emby 4.10.1.0 in isolated Docker container","steps":steps,"failure":fail,"passed_count":len(steps),"test_account_remaining":remaining,"all_recorded_accounts_deleted":all(x["deleted"] for x in created),"db_integrity":integrity,"db_counts":counts,"telegram_delivery":"NOT_RUN","telegram_command_inputs":"SIMULATED_ONLY","scheduler_invocation":"MANUAL_DIRECT_CALL","shared_main_runtime":"NOT_RUN","release_gate":"BLOCKED"}
  (root/"evidence/real-emby-lifecycle-results.json").write_text(json.dumps(result,ensure_ascii=False,indent=2))
  print("LIFECYCLE_RESULT",json.dumps(result,ensure_ascii=False),flush=True)
  if fail:raise SystemExit(1)
asyncio.run(main())
