#!/usr/bin/env python3
import pathlib,sys,json,sqlite3,hashlib,os
import yaml
root=pathlib.Path(__file__).resolve().parent
cfgpath=root/"source/config.yaml"
missing=[]
try:
 cfg=yaml.safe_load(cfgpath.read_text()) or {}
except Exception as e:
 print(json.dumps({"status":"BLOCKED","config_error_class":type(e).__name__}))
 sys.exit(2)
for section,key in [("emby","server_url"),("emby","api_key"),("emby","public_url"),("emby","template_user_id"),("telegram","bot_token"),("telegram","admin_ids")]:
 value=cfg.get(section,{}).get(key)
 if not value or isinstance(value,str) and (value.startswith("1234567890:") or "your_" in value or "example" in value):
  missing.append(section+"."+key)
if cfg.get("server",{}).get("host")!="127.0.0.1": missing.append("server.host=127.0.0.1")
if cfg.get("rules",{}).get("auto_disable_expired") is not True: missing.append("rules.auto_disable_expired=true")
if cfg.get("rules",{}).get("allow_self_reset_password") is not True: missing.append("rules.allow_self_reset_password=true")
dbpath=pathlib.Path(cfg.get("server",{}).get("db_path","")).resolve()
if not dbpath.is_relative_to(root/"data") or not dbpath.is_file(): missing.append("isolated_database_path")
if cfgpath.stat().st_mode & 0o077: missing.append("config_file_permissions_0600")
manifest=json.loads((root/"source-manifest.json").read_text())
bad=[]
for name,expected in manifest["files"].items():
 p=root/"source"/name
 if not p.is_file() or hashlib.sha1(b"blob "+str(p.stat().st_size).encode()+b"\0"+p.read_bytes()).hexdigest()!=expected: bad.append(name)
if bad: missing.append("candidate_source_changed")
integrity="not_checked"
if dbpath.is_file() and dbpath.is_relative_to(root/"data"):
 with sqlite3.connect("file:"+str(dbpath)+"?mode=ro",uri=True) as con:
  integrity=con.execute("PRAGMA integrity_check").fetchone()[0]
 if integrity!="ok": missing.append("database_integrity")
result={"status":"BLOCKED" if missing else "CONFIG_READY_EXTERNAL_TESTS_NOT_RUN","missing":missing,"candidate_sha":manifest["head_sha"],"source_files_checked":len(manifest["files"]),"source_match":not bad,"db_integrity":integrity,"secrets_printed":False,"launch_performed":False}
print(json.dumps(result,ensure_ascii=False,indent=2))
sys.exit(2 if missing else 0)
